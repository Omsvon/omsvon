//
//  Currency_Convert_v2App.swift
//  Currency Convert v2
//
//  Created by Денис Орлов on 14.03.22.
//

import SwiftUI
import Alamofire

import SwiftUI
import Alamofire
@main
struct Currency_ConvertApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
