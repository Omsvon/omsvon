//
//  Currency.swift
//  Currency Convert v2
//
//  Created by Денис Орлов on 14.03.22.
//

import Foundation
import Alamofire


struct Currency: Codable {
    var success: Bool
    var base: String
    var date: String
    var rates = [String: Double]()
}

func apiRequest(url: String, completion: @escaping (Currency) -> ()) {
    
    Session.default.request(url).responseDecodable(of: Currency.self) { response in
        switch response.result {
        case .success(let currencies):
            print(currencies)
            completion(currencies)
        case .failure(let error):
            print(error)
        }
    }
}
