//
//  ContentView.swift
//  Currency Convert v2
//
//  Created by Денис Орлов on 14.03.22.
//


import SwiftUI
import Alamofire

struct ContentView: View {
    
    @State var currencyList = [String]()
    @State var input = ""
    @State var base = "BYN"
    @FocusState private var inputIsFocused: Bool
    
    func makeRequest(showAll: Bool, currencies: [String] = ["USD", "BYN", "EUR"]) {
        apiRequest(url: "https://api.exchangerate.host/latest?base=\(base)&amount=\(input)") { currency in
            
            var tempList = [String]()
            
            for currency in currency.rates {
                
                if showAll {
                    tempList.append("\(currency.key) \(String(format: "%.3f",currency.value))")
                } else if currencies.contains(currency.key)  {
                    tempList.append("\(currency.key) \(String(format: "%.3f",currency.value))")
                }
                tempList.sort()
            }
            currencyList.self = tempList
            
        }
    }
    
    var body: some View {
        VStack() {
            HStack {
                Text("Конвертер валют")
                    .font(.system(size: 30))
                    .bold()
                
                Image(systemName: "dollarsign.circle.fill")
                    .font(.system(size: 30))
                    .foregroundColor(.blue)
                
            }
            
            
            // вывод на экран всех валют списком
            //            List {
            //                ForEach(currencyList, id: \.self) { currency in
            //                    Text(currency)
            //                }
            //            }
            
            VStack {
                Rectangle()
                    .frame(height: 8.0)
                    .foregroundColor(.blue)
                    .opacity(0.90)
                TextField("BYN" ,text: $input)
                    .padding()
                    .background(Color.gray.opacity(0.10))
                    .cornerRadius(20.0)
                    .padding()
                    .keyboardType(.decimalPad)
                    .focused($inputIsFocused)
                
                
                
                // ввод волюты текстом по названию валюты
                //                TextField("Enter a currency" ,text: $base)
                //                    .padding()
                //                    .background(Color.gray.opacity(0.10))
                //                    .cornerRadius(20.0)
                //                    .padding()
                //                    .focused($inputIsFocuse
                
                
                
                Picker("",selection: $currencyList){
                    ForEach(currencyList, id: \.self) { currency in
                        Text(currency)
                    }
                }
                .id(UUID())
                .labelsHidden.self()
                
                Button("Конвертировать!") {
                    makeRequest(showAll: true)
                    inputIsFocused = false
                }.padding()
            }
            
        }.onAppear() {
            makeRequest(showAll: true)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
